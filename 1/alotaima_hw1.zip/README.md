# HW 1

## Requirements
* Python3
* graph.txt at the same directory as lp-dag.py

## To Run
```
python3 lp-dag.py
```
